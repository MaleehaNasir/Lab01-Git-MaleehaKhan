`timescale 1ns / 1ps

module tb_processor;

reg clk;
reg reset;

wire [31:0] PC_out;
wire [31:0] ALU_out;

// Instantiate your processor
TopLevelProcessor uut (
    .clk(clk),
    .reset(reset),
    .PC_out(PC_out),
    .ALU_out(ALU_out)
);

// Clock generation (10ns period)
always #5 clk = ~clk;

initial begin
    // Initialize
    clk = 0;
    reset = 1;

    // Hold reset for some time
    #10;
    reset = 0;

    // Run simulation
    #200;

    $stop;
end

endmodule